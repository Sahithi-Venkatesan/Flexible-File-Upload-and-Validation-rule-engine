'''
from flask import Flask, render_template, request, flash
import json
app = Flask(_name_)
@app.route('/')  
def home():
    return render_template("index.html")
@app.route('/login_1', methods=['GET', 'POST'])
def login_func():
    if request.method == 'POST':
        return redirect(url_for('index'))
    return render_template('login_1.html')
    
if _name_ == "_main_":   
    app.run(debug=True)
'''
from flask import Flask, render_template, request, flash, redirect, url_for
import json
import pandas as pd
from io import StringIO
from pandas_schema import Column, Schema
from pandas_schema.validation import LeadingWhitespaceValidation, TrailingWhitespaceValidation, CanConvertValidation, MatchesPatternValidation, InRangeValidation, InListValidation, DateFormatValidation
import os
from werkzeug.utils import secure_filename
 
app = Flask(__name__)
app.secret_key = "secret key"
 
@app.route('/')  
def home():
    return render_template("index.html")
 
@app.route('/login', methods=['GET', 'POST'])
def login_func():
    if request.method == 'POST':
        return redirect(url_for('index'))
    return render_template('login.html')
 
@app.route('/upload', methods=['GET', 'POST'])
def upload_func():
    if request.method == 'POST':
        return redirect(url_for('index'))
    return render_template('upload.html')


 
Ext_check = set(['csv', 'txt'])
 
def file_check(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in Ext_check
    
'''
@app.route('/design', methods=['POST'])
def upload_file():
    if request.method == 'POST':
       
        file = request.files['file']
        if file.filename == '':
            flash('Please select a file')
            return render_template('design.html')
        if file and file_check(file.filename):
            filename = secure_filename(file.filename)
            #file.save(file.filename)  # stores file in main folder
            file.save(os.path.join('templates', filename))
            flash('File successfully uploaded')
            return render_template('design.html')
        else:
            flash('Allowed file types are txt, pdf, png, jpg, jpeg, gif')
            return render_template('design.html')
@app.route('/design', methods=['post', 'get'])
def retrieve():
    if request.method == 'POST':
        s = request.form.get('s')
        print(s)
        return redirect(url_for('login'))
    return render_template('design.html')
'''
@app.route('/design', methods=['post', 'get'])
def design():
    if request.method == 'POST':
        values=0
        if request.form.get('columns') == '1':
            a=request.form.get('columns')
            values=1
            print(a)
            return render_template("design.html",value=a,values=values)
        count=1
        if request.form.get('columns') == '2':
            a=request.form.get('columns')
            values=2
            print(a)
            return render_template("design.html",value=a,values=values)
        if request.form.get('columns') == '3':
            a=request.form.get('columns')
            values=3
            print(a)
            return render_template("design.html",value=a,values=values)
        if request.form.get('columns') == '4':
            a=request.form.get('columns')
            values=4
            print(a)
            return render_template("design.html",value=a,values=values)
        if request.form.get('columns') == '5':
            a=request.form.get('columns')
            values=5
            print(a)
            return render_template("design.html",value=a,values=values)
        #value = None
        cnum0 = request.form.get('cnum0')
        cnum1 = request.form.get('cnum1')
        cnum2 = request.form.get('cnum2')
        cnum3 = request.form.get('cnum3')
        cnum4 = request.form.get('cnum4')
        d0 = request.form.get('d0')
        d1 = request.form.get('d1')
        d2 = request.form.get('d2')
        d3 = request.form.get('d3')
        d4 = request.form.get('d4')
      
        c0=""
        c1=""
        c2=""
        if int(cnum1 or 123) is None:
            cnum1=""
        if int(cnum2 or 23) is None:
            cnum2=""
       
        if cnum2=='2':
            test_data = pd.read_csv(StringIO('''Age,Name,Age
            32,    Sahithi,40
            300,Shreya,50
            24,Bhavana,60'''))
            if d0=='Age':
                c0=InRangeValidation(0, 30)
            if d0=='Name':
                c0=LeadingWhitespaceValidation()
            if d1=='Age':
                c1=InRangeValidation(0, 30)
            if d1=='Name':
                c1=LeadingWhitespaceValidation()
            if d2=='Age':
                c2=InRangeValidation(0, 30)
            if d2=='Name':
                c2=LeadingWhitespaceValidation()
            list=[]
            for col in test_data.columns:
                list.append(col)
            schema = Schema([Column(list[int(cnum0)], [c0]),Column(list[int(cnum1)], [c1]),Column(list[int(cnum2)], [c2]) ])
            errors = schema.validate(test_data)
            for error in errors:
                print(error)
            return redirect(url_for('design'))
        elif cnum1=='1':
            test_data = pd.read_csv(StringIO('''Age,Name
            32,    Sahithi
            300,Shreya
            24,Bhavana'''))
            if d0=='Age':
                c0=InRangeValidation(0, 30)
            if d0=='Name':
                c0=LeadingWhitespaceValidation()
            if d1=='Age':
                c1=InRangeValidation(0, 30)
            if d1=='Name':
                c1=LeadingWhitespaceValidation()
            list=[]
            for col in test_data.columns:
                list.append(col)
            schema = Schema([Column(list[int(cnum0)], [c0]),Column(list[int(cnum1)], [c1]) ])
            errors = schema.validate(test_data)
            for error in errors:
                print(error)
            return redirect(url_for('design'))
        else:
            test_data = pd.read_csv(StringIO('''Age
            32
            300
            24'''))
            if d0=='Age':
                c0=InRangeValidation(0, 30)
            if d0=='Name':
                c0=LeadingWhitespaceValidation()
            list=[]
            for col in test_data.columns:
                list.append(col)
            schema = Schema([Column(list[int(cnum0)], [c0])])
            errors = schema.validate(test_data)
            for error in errors:
                print(error)
            return redirect(url_for('design'))
        return redirect(url_for('design'))
    elif request.method == 'GET':
        # return render_template("index.html")
        print("No Post Back Call")
    return render_template("design.html") 
 
if __name__ == "__main__":   
    app.run(debug=True)